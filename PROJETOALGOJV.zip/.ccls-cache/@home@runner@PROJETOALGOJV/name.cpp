#include <iostream>
#include <fstream>
#include "idosa.h"
using namespace std;

bool validarNickname(const string& nickname) { //valida os nomes (ter no maximo 3 caracteres)...
    return nickname.length() <= 3;
}

void exibirNicknames() {//exibe os nomes dos vencedores...
    ifstream arquivo("vencedores.txt");
    string nickname;

    cout << "Lista dos Vencedores:\n";

    while (arquivo >> nickname) {
        cout << nickname << endl;
    }

    arquivo.close();
}

void addNickname(const string& novoNickname) {//adiciona os nomes dos vencedores no arquivo...
    if (validarNickname(novoNickname)) {
        ofstream arquivo("vencedores.txt", ios::app);
        arquivo << novoNickname << endl;

        arquivo.close();
    } 
  
}
