#include <iostream> 
using namespace std;

void LobbyJogo(int b){



  switch(b){

    case 1:
      if(b==1){
        //jogo...
        cout << "\niniciando jogo... " << endl;
        cout << "\t________________________________\n";
        cout << "\t________________________________\n";
        cout << "\t________________________________\n";
        cout << endl;


      } break;

    case 2:
      if(b==2){
        cout << "\nsaindo...\n";
        cout << "________________________________\n";
        exit(0);
      } break;

   }

}

