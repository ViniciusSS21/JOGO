#include<iostream>
using namespace std;
//-------------------------------------------------------
void LobbyJogo(int b);
void Jogo(string play1, string play2);
bool validarNickname(const string& nickname);
void exibirNicknames();
void adicionarNickname(const string& novoNickname);
//-------------------------------------------------------