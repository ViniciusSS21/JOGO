#include <iostream> 
#include "idosa.h"
using namespace std;

void LobbyJogo(int b){//, string p1, string p2){

  //string play1, play2;

  switch(b){

    case 1:
      if(b==1){
        //jogo...
        cout << "\niniciando jogo... " << endl;
        cout << "\n";
        cout << "\n";
        cout << "\n";
        /*cout << endl;
        cout << "digite o nome de P1:" << endl;
        cin >> p1;
        cout << "digite o nome de P2:" << endl;
        cin >> p2;
        cout << endl;
        cout << endl;
        cout << "\t" << "|-"<< play1 << "-|"<< " vs " << "|-"<< play2 << "-|"<< endl;
        cout << endl;
        cout << endl;*/

      } break;

    case 2:
      if(b==2){
        cout << "\nsaindo...\n";
        cout << "________________________________\n";
        exit(0);
      } break;

   }

}

