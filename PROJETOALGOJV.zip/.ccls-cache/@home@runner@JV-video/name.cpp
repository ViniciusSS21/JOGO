#include <iostream>
#include <fstream>
#include "idosa.h"
using namespace std;


bool validarNickname(const string& nickname) {
    return nickname.length() <= 3;
}

void exibirNicknames() {
    ifstream arquivo("vencedores.txt");
    string nickname;

    cout << "Lista dos Vencedores:\n";

    while (arquivo >> nickname) {
        cout << nickname << endl;
    }

    arquivo.close();
}

void adicionarNickname(const string& novoNickname) {
    if (validarNickname(novoNickname)) {
        ofstream arquivo("vencedores.txt", ios::app);
        arquivo << novoNickname << endl;

        arquivo.close();
    } 
  
}
