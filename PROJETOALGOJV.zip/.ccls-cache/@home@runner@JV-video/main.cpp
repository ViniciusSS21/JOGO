#include <iostream>
#include "idosa.h"
using namespace std;
//-------------------------------------------------------
//void LobbyJogo(int b);
//void Jogo(string play1, string play2);
//-------------------------------------------------------

int main(){

  int a;
  string p1, p2;
  //inicio:
  cout << "\tBem vindo ao Jogo da Velha" << endl;
  cout << "\n" << "(1)Começar jogo..." << "\n" << endl << "(2)Sair..."<<endl;

  cin >> a;
  
  //erros: 
  while(a<1 || a>2){
    cout << "ERRO...DIGITE UM NUMERO VALIDO:";
    cin >> a;
  }
  
  //lobby
  LobbyJogo(a);

  //
  if(a==1){
    Jogo(p1, p2);
  }
  return 0;
}
